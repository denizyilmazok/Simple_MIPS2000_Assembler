import pickle
import FilesHandling
import Assemble
import sys
registers = {}


# This function assembles one instruction at a time
# This is used in both the interactive mode and batch mode
def assembleOneInstruction(instruction, ):
    # This takes the instruction operation only
    operation = instruction.split(" ", 1)
    if len(operation) == 1:
        return "Error invalid instruction format"
    # This strips what is left from spaces to facilitate working with strings
    instructionBody = operation[1].replace(" ", "").split(",")

    # We lookup the operation in our lookup table. If it's not a supported instruction we print an error and close.
    operation = operation[0]
    try:
        opcode = opcodeLookUpTable[operation]
    except KeyError:
        return "Error This is not a valid opcode!"

    # opcode now has a tuple which contains something like ("I1", "100011")
    instructionType = opcode[0]
    opcode = opcode[1]
    # print(instructionType, opcode, instructionBody)

    # The case when the instruction is R Type (can be R1, R2 or R3)
    if instructionType.startswith("R"):
        function = opcode
        result = Assemble.assembleR(instructionType, function, instructionBody, registers)

    # The case when the instruction is R Type (can be I1 or I2)
    elif instructionType == "I1" or instructionType == "I2":
        result = Assemble.assembleI(instructionType, opcode, instructionBody, registers)

    # The case when the instruction is J Type
    elif instructionType == "J":
        try:
            result = Assemble.assembleJ(instructionType, opcode, instructionBody, pcLabels)
        except NameError:
            return "Error! The J instructions doesn't work in the interactive mode"
    # If assembling returns an error
    if result.startswith("Error"):
        return result
    # If no error occurred we convert it to hex and print it and save it to a file
    result = hex(int(result, 2)).replace("0x", "").zfill(8)
    return result


# Here we take the right the file names
# These are default file names will be used when there is no file name(s) specified.
givenFileName1 = "input.txt"
givenFileName2 = "output.txt"
# The starting PC gives a PC count from the start of the input file
startPC = 0


# Press the green button on the left of line to run the script. (PyCharm feature)
if __name__ == '__main__':

    fileArguments = len(sys.argv)

    # loading the look up tables
    opcodeLookUpTable = FilesHandling.readDataFile("opcodeLockUp.dat")
    registers = FilesHandling.readDataFile("registers.dat")

    if fileArguments != 1 and fileArguments != 3:
        print("Error! The file should have 0 arguments or 2 arguments for input and output File")
        exit(1)

    elif fileArguments == 1:
        print("This is interactive mode!")

        choice = input("\nMenu\n____\nEnter 1 for single line interactive mode\n2 for entering files names\n0 for exit\n")
        if choice == "0":
            print("Thanks for using our program ^_^")
            exit(0)
        elif choice == "1":
            while True:
                print("Enter an instruction or 0 to end the program: ")
                choice = input()
                if choice.startswith("0"):
                    print("Thanks for using our program ^_^")
                    exit(0)
                else:
                    result = assembleOneInstruction(choice)
                    print(result)
                    print()
        elif choice == "2":
            givenFileName1 = input("Enter input file.txt name  ")
            givenFileName2 = input("Enter output file.txt name  ")

    elif fileArguments == 3:
        givenFileName1 = sys.argv[1]
        givenFileName2 = sys.argv[2]

    # FilesHandling.modifyFiles() # here for creating .dat files # commented out

    # reading the instruction files into a list of lines ***
    try:
        inFile = open(givenFileName1, "r")
        fileLines = inFile.readlines()
        inFile.close()
    except FileNotFoundError:
        print(" The input file is not found")
        exit(1)

    # This line deletes the "\n" from the end of each line
    fileLines = [line.strip() for line in fileLines]

    lines = []
    pcLabels = {}

    # if the input file is empty
    if len(fileLines) == 0:
        print("Error! The input file is empty")
        exit(1)

    # This loop is for checking if there are labels
    # If a label is found we save it in pcLabels with the equivalent PC and strip the instruction from it
    for i in range(0, len(fileLines)):
        pc = i * 4 + startPC
        instruction = fileLines[i]

        if ":" in instruction:
            label, instruction = instruction.split(":", 1)
            label = label.replace(" ", "")
            pcLabels[label] = pc
            instruction = instruction.strip(" ")

        # when we have a move in the file  ***
        elif instruction.startswith("move"):
            move, body = instruction.split(" ", 1)
            # This strips what is left from spaces to facilitate working with strings
            instructionBody = body.replace(" ", "").split(",")
            count = len(instructionBody)
            if count != 2:
                print("Error! Wrong argument count for move instruction")
                exit(1)
            else:
                instruction = "add {},$zero,{}".format(instructionBody[0], instructionBody[1])

        lines.append(instruction)

    # after the previous loop we have a list of instructions and a dictionary pcLabels with equivalent PCs

    ################################################################################################
    # here we open an output file
    outFile = open(givenFileName2, "w")

    # This loop does the assembling
    for i in range(0, len(lines)):
        pc = i * 4 + startPC
        instruction = lines[i]

        result = assembleOneInstruction(instruction)

        if result.startswith("Error"):
            print(result)
            outFile.close()
            exit(1)

        print(result)
        outFile.write(result)
        outFile.write("\n")
    outFile.close()
