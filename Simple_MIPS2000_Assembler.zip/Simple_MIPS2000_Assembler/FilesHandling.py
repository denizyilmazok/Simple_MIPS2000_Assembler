# This file handles the file useage
# contains auxiliary functions
# some of them to prepare the loackup tables and used only once and not used while the program is running
# some of them are used while the program is running


import pickle


# This function takes a file name and reads its contents to dictionary of keys and values
# Then it returns the dictionary
# It's not used in the program
def readTable(fileName):
    infile = open(fileName, "r")
    fileLines = infile.readlines()
    infile.close()
    fileLines = [line.strip().split(" ") for line in fileLines]

    table = {}
    for line in fileLines:
        table[line[0]] = line[1]
    return table


# This function reads instructions from a txt file then save the names in a set
# Used to prepare the files
# It's not used in the program
def readInstructionSet(fileName):
    infile = open(fileName, "r")
    fileLines = infile.readlines()
    infile.close()
    fileLines = [line.strip().split(" ") for line in fileLines]

    tmpSet = set()
    for line in fileLines:
        tmpSet.add(line[0])
    return tmpSet


# This functions reads instructions and its opcodes from a txt file then save it to a dictionary
# each key has a tuple:  instructionName -> (instructionType, opcode)
# This is used to prepare the lock up table
# It's not used in the program
def readInstructionTable(fileName):
    infile = open(fileName, "r")
    fileLines = infile.readlines()
    infile.close()
    fileLines = [line.strip().split(" ") for line in fileLines]

    instructionType = fileName.split(".")[0]
    table = {}
    for line in fileLines:
        table[line[0]] = (instructionType, line[1])
    return table


# This function used previous functions to read from all given txt files and then saving dictionaries to work on
# This dictionaries are saved in .dat files and will be read using pickle in the program
# This function is for preparing lockup tables' files
# It's not used in the program
def readTxtFiles():
    # registers = readTable("registers.txt")
    # writeDataFile("registers.dat", registers)
    # hex = readTable("hex.txt")
    # writeDataFile("hex.dat", hex)
    # functionLockUpTable = FilesHandling.readTable("functions.txt")
    # FilesHandling.writeDataFile("functionLockUp.dat", functionLockUpTable)

    R = readInstructionTable("R.txt")
    writeDataFile("R.dat", R)
    J = readInstructionTable("J.txt")
    writeDataFile("J.dat", J)
    I = readInstructionTable("I.txt")
    writeDataFile("I.dat", I)
    I2 = readInstructionTable("I1.txt")
    writeDataFile("I1.dat", I2)
    I3 = readInstructionTable("I2.txt")
    writeDataFile("I2.dat", I3)

    opcode = {}
    opcode.update(I)
    opcode.update(R)
    opcode.update(J)

    writeDataFile("opcodeLockUp.dat", opcode)
    return opcode


# This a function that takes a dictionary and save it to a file using pickle package
# This is used by readTxtFiles a lot to prepare the lockup tables
# It's not used in the program
def writeDataFile(fileName, values):
    outFile = open(fileName, "wb")
    pickle.dump(values, outFile)
    outFile.close()


############################################################################################
# This is the important function in this file
# This is the function that is used to pre saved .dat files that contain the lookup tables
# It takes a file name to open it and return a dictionary with its contents
def readDataFile(fileName):
    inFile = open(fileName, "rb")
    readData = pickle.load(inFile)
    inFile.close()
    return readData
############################################################################################


# This is a function that saves different I types instructions to differentiate
# between addi $, $, imm and lw $, imm($)
# This is used to prepare the pre saved files
# It's not used in the program
def writeSetFiles():
    setI1 = readInstructionSet("I1.txt")
    writeDataFile("I1Set.dat", setI1)
    setI2 = readInstructionSet("I2.txt")
    writeDataFile("I2Set.dat", setI2)


# This function that modifies files in a certain way to prepare the pre saved lookup tables
# It's not used in the program
def modifyFiles():
    writeSetFiles()
    I1Set = readDataFile("I1Set.dat")
    I2Set = readDataFile("I2Set.dat")
    opcodeLockUpTable = readDataFile("opcodeLockUp.dat")

    # print(opcodeLockUpTable)
    for key in opcodeLockUpTable.keys():
        if key in I1Set:
            opcode = opcodeLockUpTable[key][1]
            opcodeLockUpTable[key] = ("I1", opcode)
        elif key in I2Set:
            opcode = opcodeLockUpTable[key][1]
            opcodeLockUpTable[key] = ("I2", opcode)
        elif key in ["sll", "srl", "sra"]:
            opcode = opcodeLockUpTable[key][1]
            opcodeLockUpTable[key] = ("R2", opcode)
        elif key == "jr":
            opcode = opcodeLockUpTable[key][1]
            opcodeLockUpTable[key] = ("R3", opcode)
        elif not key.startswith("j"):
            opcode = opcodeLockUpTable[key][1]
            opcodeLockUpTable[key] = ("R1", opcode)
    print(opcodeLockUpTable)
    writeDataFile("opcodeLockUp.dat", opcodeLockUpTable)