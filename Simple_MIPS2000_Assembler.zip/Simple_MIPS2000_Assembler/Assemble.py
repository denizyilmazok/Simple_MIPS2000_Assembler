# in this files we have the important functions that does the assembling


# This function takes a number either a binary or hex or decimal. Negative or Positive.
# It converts the number to binary string
# It takes a bitWidth variable for filling the string with a specific width
# It returns the binary string
# Note: Despite of the name it can handle any number needing converting not only an immediate value
def immediateToBinary(immediateValue, bitWidth):
    # The case when the number is binary it deletes the prefix and checks the boundaries
    if immediateValue.startswith("0b") or immediateValue.startswith("0B"):
        Value = immediateValue.replace("0b", "")
        Value = immediateValue.replace("0B", "")
        if immediateValue.count() > 16:
            return "Error This value is higher than allowed max binary number!"

    # The case when the number is hexadecimal it deletes the prefix and checks the boundaries
    elif immediateValue.startswith("0x") or immediateValue.startswith("0X"):
        Value = immediateValue.replace("0x", "")
        Value = immediateValue.replace("0X", "")
        if immediateValue.count() > 4:
            return "Error This value is higher than allowed max hex number!"
        else:
            # if it passes the checks it is sent to be converted to a corresponding binary value
            Value = int(immediateValue, bitWidth)   # ** check here if bitWidth is a variable not 16

    # The case when the number is decimal it checks the boundaries and convert it to binary
    # It handles the negative values as well
    elif immediateValue.isdigit() or (immediateValue.startswith("-") and immediateValue[1:].isdigit()):
        Value = int(immediateValue)
        if Value < -32768 or Value > 32767:
            return "Error This value is higher than allowed max decimal number!"
        elif Value > -1:
            Value = str(bin(Value)).replace("0b", "").zfill(bitWidth)
        else:
            Value = bin(Value + (1 << bitWidth))  # ** check that zero in signed numbers is 00000000
        Value = str(Value).replace("0b", "")

    # The case when the input is not correct return error message
    else:
        return "Error This is not a valid value for immediate!"

    # after handling all the cases we return the Value
    return Value


# This function assembles Type R instructions
# instructionType should contain R1, R2, R3
# each one represents different way of assembling
# function is the function for the instruction
# instructionBody contains a list of the remaining inputs
# For example add $s1, $s2, $s3  -> function will be for add and instructionBody = [$s1, $s2, $s3]
# registers is the lookup table for assembling registers or to detect errors when the body contain a non register value
def assembleR(instructionType, function, instructionBody, registers):

    # first we get the count to chek the count of arguments for each specific instruction
    count = len(instructionBody)

    # This is specific for jr instruction
    if count == 1:
        if instructionType != "R3":
            return "Error Wrong argument count for R instruction"
        else:
            register1 = instructionBody[0]
            try:
                register1 = registers[register1]
            except KeyError:
                return "Error Wrong name of a register"
            Value = "000000{}000000000000000{}".format(register1, function)

    # This case when the count of arguments is not 3. ass all other R type instructions should have 3 registers
    elif count != 3:
        return "Error Wrong argument count for R instruction"

    # This case when the shift amount is 00000 for specific R type instructions
    elif instructionType == "R1":
        register1 = instructionBody[0]
        register2 = instructionBody[1]
        register3 = instructionBody[2]

        # Using lookup table to get the binary values
        try:
            register1 = registers[register1]
            register2 = registers[register2]
            register3 = registers[register3]
        except KeyError:
            return "Error Wrong name of a register"

        Value = "000000{}{}{}00000{}".format(register2, register3, register1, function)

    # This case when the shift amount is not 00000 for specific R type instructions
    elif instructionType == "R2":
        register1 = instructionBody[0]
        register2 = instructionBody[1]

        # Using lookup table to get the binary values
        # Note these instructions have only two registers and a shift amount in decimal # ** check for info validity
        try:
            register1 = registers[register1]
            register2 = registers[register2]
        except KeyError:
            return "Error Wrong name of a register"

        shiftAmount = instructionBody[2]
        if not shiftAmount.isdigit():
            return "Error The Shift Amount should be decimal"
        shiftAmount = int(shiftAmount)
        if shiftAmount > 31:
            return "Error The Shift Amount should be between 0 and 31"

        # This converts the shift amount to 5 bits binary number
        shiftAmount = str(bin(shiftAmount)).replace("0b", "").zfill(5)
        Value = "00000000000{}{}{}{}".format(register2, register1, shiftAmount, function)

    return Value


# This function assembles Type I instructions
# @instructionType should contain I1, I2
# each one represents different way of assembling
# @function is the function for the instruction
# @instructionBody contains a list of the remaining inputs
# For example addi $s1, $s2, 100  -> function will be for add and instructionBody = [$s1, $s2, 100]
# @registers is the lookup table for assembling registers or to detect errors when the body contain a non register value
def assembleI(instructionType, opcode, instructionBody, registers):

    # This checks for the count of the arguments
    count = len(instructionBody)

    # I2 has only two arguments
    # Its the Type I where there are brackets like  lw $s0, 100($s1)
    if instructionType == "I1":
        if count != 2:
            return "Error Wrong argument count for I instruction"
        register1 = instructionBody[0]

        # for this type we need to modify the second argument to get rd, rt, imm
        if "(" in instructionBody[1] and instructionBody[1].endswith(")"):
            body = instructionBody[1].split("(")
            if len(body) != 2:
                return "Error Wrong brackets count"
            immediateValue = body[0]
            register2 = body[1][:-1]

    # I2 has three arguments
    # Its the Type I where there are brackets like  addi $s0, $s1, 100
    elif instructionType == "I2":
        if count != 3:
            return "Error Wrong argument count for I instruction"
        register1 = instructionBody[0]
        register2 = instructionBody[1]
        immediateValue = instructionBody[2]

        # for beq & bne the order of the rd, rt is reversed in assembling
        if opcode == "000100" or opcode == "000101":
            register1, register2 = register2, register1

    # Using lookup table to get the binary values
    try:
        register1 = registers[register1]
        register2 = registers[register2]
    except KeyError:
        return "Error Wrong name of a register"

    # creating the immediate value
    # Note: the function checks for errors
    immediateValue = immediateToBinary(immediateValue, 16)
    if immediateValue.startswith("Error"):
        return immediateValue
    else:
        return "{}{}{}{}".format(opcode, register2, register1, immediateValue)


# This function assembles Type J instructions
# @instructionType should contain J  ** not used here now
# each one represents different way of assembling
# @function is the function for the instruction
# @instructionBody contains a list of the remaining inputs
# For example addi $s1, $s2, 100  -> function will be for add and instructionBody = [$s1, $s2, 100]
# @labels is a dictionary which is used when the argument to instruction j, jal is labelled with a name for a PC address
def assembleJ(instructionType, opcode, instructionBody, pcLabels):
    count = len(instructionBody)
    if count != 1:
        return "Error Wrong argument count for J instruction"
    label = instructionBody[0]

    # The case when the argument is a digit we calculate the pc directly (using direct addressing)
    if label.isdigit():
        pc = int(label)

    # The case when the argument is a string we check if this string is a label with a saved PC
    # We use the dictionary to get the value of the PC for the label
    else:
        try:
            pc = pcLabels[label]
        except KeyError:
            return "Error The label {} is not in the  name of a register".format(label)

    # Here we convert the address to 26 bits binary number
    immediateValue = immediateToBinary(str(pc // 4), 26)
    if immediateValue.startswith("Error"):
        return immediateValue
    else:
        return "{}{}".format(opcode, immediateValue)

